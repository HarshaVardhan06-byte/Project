window.onload = function () {
  const defaultTasks = ["Learn JavaScript", "Complete Resume", "Apply for Internship", "Update GitHub"];
  const taskList = document.getElementById("taskList");
  defaultTasks.forEach(task => {
    const li = document.createElement("li");
    li.textContent = task;
    li.onclick = function () {
      li.classList.toggle("done");
    };
    li.ondblclick = function () {
      taskList.removeChild(li);
    };
    taskList.appendChild(li);
  });
};

function addTask() {
  const taskInput = document.getElementById("taskInput");
  const taskText = taskInput.value.trim();
  if (taskText === "") return;

  const taskList = document.getElementById("taskList");
  const li = document.createElement("li");
  li.textContent = taskText;

  li.onclick = function () {
    li.classList.toggle("done");
  };

  li.ondblclick = function () {
    taskList.removeChild(li);
  };

  taskList.appendChild(li);
  taskInput.value = "";
}
